const theme = {
    colors: {
        primary: "#4361ee",
        secondary: "#b5179e",
    },

};

export default theme;