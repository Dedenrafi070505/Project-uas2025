import Container from "../components/Container";
import Footer from "../components/footer/Footer";
import Navbar from "../components/navbar/Navbar";

function Layout({ children }) {
  return (
    <>
      <Navbar />
      <main>
        <Container>{children}</Container>
      </main>
      <Footer />
    </>
  );
}

export default Layout;
