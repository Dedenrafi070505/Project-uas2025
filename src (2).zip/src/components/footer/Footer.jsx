// import styles from './Footer.module.css';
import styled from "styled-components";

const StyledFooter = styled.div`
  background-color: #4361ee;
  color: #fff;
  padding: 1rem;
  text-align: center;

  footer h2 {
    margin-bottom: 1rem;
  }

  footer p {
    margin-bottom: 1rem;
  }
`;

function Footer() {
  return (
    <StyledFooter>
      <footer>
        <h2>Movie App</h2>
        <p>Created by Deden rafi akbar</p>
      </footer>
    </StyledFooter>
  );
}

export default Footer;