import styled from "styled-components";
import { useState, useEffect } from "react";
import axios from "axios";

const StyledHero = styled.div`
  margin: 1rem;

  section {
    display: flex;
    flex-direction: column;
    text-align: center;
  }

  section > div:first-child {
    margin-bottom: 1rem;
  }

  h2 {
    color: #4361ee;
    margin-bottom: 1rem;
    font-size: 2.44rem;
  }

  h3 {
    color: #b5179e;
    margin-bottom: 1rem;
    font-size: 1.59rem;
  }

  p {
    color: #64748b;
    margin-bottom: 1rem;
  }

  button {
    padding: 0.8rem 2rem;
    border: none;
    border-radius: 10px;
    background-color: #039314;
    color: #fff;
    cursor: pointer;
  }

  img {
    max-width: 50%;
    height: auto;
    border-radius: 25px;
  }

  @media (min-width: 992px) {
    margin: 3rem auto;
    max-width: 1200px;

    section {
      margin: 0 1rem;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      text-align: left;
    }

    section > div:first-child {
      flex-basis: 40%;
    }

    section > div:last-child {
      flex-basis: 60%;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
`;

function Hero() {
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    async function fetchMovieData() {
      try {
        const API_KEY = import.meta.env.VITE_API_KEY;

        // Ambil film trending
        const trendingURL = `https://api.themoviedb.org/3/trending/movie/day?api_key=${API_KEY}`;
        const trendingResponse = await axios.get(trendingURL);
        const firstMovie = trendingResponse.data.results[0];

        // Ambil detail film
        const detailURL = `https://api.themoviedb.org/3/movie/${firstMovie.id}?api_key=${API_KEY}&append_to_response=videos`;
        const detailResponse = await axios.get(detailURL);

        setMovie(detailResponse.data);
      } catch (error) {
        console.error("Gagal memuat data film:", error);
      }
    }

    fetchMovieData();
  }, []);

  if (!movie) return <p>Loading...</p>;

  return (
    <StyledHero>
      <section>
        <div>
          <h2>{movie.title}</h2>
          <h3>Genre: {movie.genres.map((genre) => genre.name).join(", ")}</h3>
          <p>{movie.overview}</p>
          <button>Watch</button>
        </div>
        <div>
          {movie.poster_path && (
            <img
              src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
              alt={movie.title}
            />
          )}
        </div>
      </section>
    </StyledHero>
  );
}

export default Hero;
