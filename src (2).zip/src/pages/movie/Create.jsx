import Navbar from "../../components/navbar/Navbar";
import Footer from "../../components/footer/Footer";

function CreateMovie() {
  return (
    <>
      <h2>Create Movie</h2>
    </>
  );
}

export default CreateMovie;
