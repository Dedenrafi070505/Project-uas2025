import Navbar from '../components/navbar/Navbar'
import Footer from '../components/footer/Footer'
import Hero from '../components/hero/Hero'
import Movies from '../components/movies/Movies'
import { useState } from 'react'
// import { data } from 'react-router-dom'
import AddMovieForm from '../components/AddMovie/AddMovieForm'
import data from '../utils/constans/data';
import Button from '../components/UI/Button'


function Home() {

    const [movies, setMovies] = useState(data);
    return(
        <div>
                <Hero/>
                <Button variant="secondary">Lihat</Button>
                <Button variant="primary">Lihat</Button>
                <Movies movies={movies} setMovies={setMovies}/>
                <AddMovieForm movies={movies} setMovies={setMovies} />
        </div>
    );
}

export default Home;