import { Route, Routes } from "react-router-dom";
import Hello from "./components/Hello";
// import './App.css'
import Home from "./pages/Home";
import CreateMovie from "./pages/movie/Create";
import PopularMovie from "./pages/movie/Popular";
import NowPlayingMovie from "./pages/movie/NowPlaying";
import TopRatedMovie from "./pages/movie/TopRated";
import Counter from "./components/Counter/Counter";
import Layout from "./Layout";
import { ThemeProvider } from "styled-components";
import theme from "./utils/constans/theme";
import GlobalStyle from "./components/GlobalStyle";
import DetailMovie from "./pages/Detail";

function App() {
  return (
    <>
      {/* <Home/> */}
      <ThemeProvider theme={theme}>
        <GlobalStyle />
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/movie/Create" element={<CreateMovie />} />
            <Route path="/movie/Popular" element={<PopularMovie />} />
            <Route path="/movie/now" element={<NowPlayingMovie />} />
            <Route path="/movie/top" element={<TopRatedMovie />} />
            <Route path="/counter" element={<Counter />} />
            <Route path="/movie/:id" element={<DetailMovie />} />
          </Routes>
        </Layout>
      </ThemeProvider>
    </>
  );
}

export default App;
